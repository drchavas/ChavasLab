%r_rhinput.m

%Purpose: calculate r for given relative humidity, p, T

%Created: 8 April 2014, Dan Chavas


function [r] = r_rhinput(p,T,rh)


%%If needed, load constants from CM1
constants_CM1_createdatfile();  %creates constants_CM1_list
load constants_CM1_list


%%calculate saturation vapor pressures
T_C = T-273.15;
es = 611.2*exp((17.67*T_C)./(T_C+243.5));  %[Pa]

%%calculate saturation mixing ratios
rs = epsil*(es./(p-es));  %[kg/kg]

%%calculate r for desired relative humidity
r = rh.*rs;

end